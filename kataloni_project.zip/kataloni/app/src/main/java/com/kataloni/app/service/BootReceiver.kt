package com.kataloni.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * On boot, if the user had the proxy running before shutdown and overlay
 * permission is already granted, quietly bring the bubble back. We do NOT
 * auto-reconnect the VPN itself -- that always needs the user to tap
 * Connect again (VpnService.prepare() can't be silently re-approved).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences("kataloni", Context.MODE_PRIVATE)
        val wasRunning = prefs.getBoolean("panel_was_running", false)
        if (wasRunning && Settings.canDrawOverlays(context)) {
            context.startForegroundService(Intent(context, FloatingPanelService::class.java))
        }
    }
}
