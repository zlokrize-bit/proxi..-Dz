package com.kataloni.app.data

/**
 * One selectable "region" in the app.
 *
 * host/port here are PLACEHOLDERS. Nothing in this project reaches a real
 * proxy server yet -- wire these fields up to your own VPS/proxy endpoints
 * (see ProxyVpnService.kt for the one place that needs to change) before
 * this does anything on real traffic.
 */
data class ProxyRegion(
    val id: String,
    val countryName: String,
    val flagEmoji: String,
    val host: String,
    val port: Int,
    val pingMs: Int? = null
)

object ProxyRegionRepository {

    // TODO: replace with your real servers (country, host, port) once you
    // have VPS instances running in each location.
    val regions = listOf(
        ProxyRegion("us", "الولايات المتحدة", "🇺🇸", "us.yourserver.example", 51820),
        ProxyRegion("de", "ألمانيا", "🇩🇪", "de.yourserver.example", 51820),
        ProxyRegion("fr", "فرنسا", "🇫🇷", "fr.yourserver.example", 51820),
        ProxyRegion("tr", "تركيا", "🇹🇷", "tr.yourserver.example", 51820),
        ProxyRegion("sg", "سنغافورة", "🇸🇬", "sg.yourserver.example", 51820),
        ProxyRegion("jp", "اليابان", "🇯🇵", "jp.yourserver.example", 51820),
        ProxyRegion("br", "البرازيل", "🇧🇷", "br.yourserver.example", 51820),
        ProxyRegion("eg", "مصر", "🇪🇬", "eg.yourserver.example", 51820),
        ProxyRegion("ae", "الإمارات", "🇦🇪", "ae.yourserver.example", 51820),
        ProxyRegion("dz", "الجزائر", "🇩🇿", "dz.yourserver.example", 51820)
    )
}
