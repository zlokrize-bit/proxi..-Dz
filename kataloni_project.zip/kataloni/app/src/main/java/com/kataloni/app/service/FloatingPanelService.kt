package com.kataloni.app.service

import android.app.*
import android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY
import android.app.NotificationManager.INTERRUPTION_FILTER_ALL
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.kataloni.app.R

/**
 * Keeps a small draggable bubble on screen over any app/game. Tapping it
 * expands a feature menu. The bubble is tied to this foreground service, so
 * it stays up as long as the service is running -- i.e. until the user
 * disconnects the proxy from MainActivity (we never auto-kill it).
 */
class FloatingPanelService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var menuView: View? = null
    private var menuOpen = false

    companion object {
        private const val CHANNEL_ID = "kataloni_panel"
        private const val NOTIF_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------------------------------------------------------------
    // Notification (required for a foreground service)
    // ---------------------------------------------------------------------

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "KATA LONI Panel", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("KATA LONI نشط")
            .setContentText("البروكسي شغال والبانل متاح فوق التطبيقات")
            .setSmallIcon(R.drawable.ic_bubble)
            .setOngoing(true)
            .build()
    }

    // ---------------------------------------------------------------------
    // Floating bubble (always visible, draggable)
    // ---------------------------------------------------------------------

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.view_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false

        bubbleView!!.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(bubbleView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleMenu()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubbleView, params)
    }

    // ---------------------------------------------------------------------
    // Feature menu (opens from the bubble)
    // ---------------------------------------------------------------------

    private fun toggleMenu() {
        if (menuOpen) closeMenu() else openMenu()
    }

    private fun openMenu() {
        if (menuView != null) return
        val inflater = LayoutInflater.from(this)
        menuView = inflater.inflate(R.layout.view_panel_menu, null)

        menuView!!.findViewById<View>(R.id.featureDnd).setOnClickListener { toggleDnd() }
        menuView!!.findViewById<View>(R.id.featureCloseBg).setOnClickListener { closeBackgroundApps() }
        menuView!!.findViewById<View>(R.id.featureQuickLaunch).setOnClickListener { quickLaunch() }
        menuView!!.findViewById<View>(R.id.featureClearCache).setOnClickListener { clearCache() }
        menuView!!.findViewById<View>(R.id.featurePerfMode).setOnClickListener { togglePerfMode() }
        menuView!!.findViewById<View>(R.id.menuBackground).setOnClickListener { closeMenu() }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(menuView, params)
        menuOpen = true
    }

    private fun closeMenu() {
        menuView?.let { windowManager.removeView(it) }
        menuView = null
        menuOpen = false
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ---------------------------------------------------------------------
    // Features
    // ---------------------------------------------------------------------

    /** Toggles system Do Not Disturb. Requires the user to grant Notification
     *  Policy Access once (Settings > Notifications > DND access) -- Android
     *  does not allow this to be auto-granted. */
    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            val intent = Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            return
        }
        val turningOn = nm.currentInterruptionFilter != INTERRUPTION_FILTER_PRIORITY
        nm.setInterruptionFilter(if (turningOn) INTERRUPTION_FILTER_PRIORITY else INTERRUPTION_FILTER_ALL)
        closeMenu()
    }

    /** Android does not let one app force-kill another's process (by design,
     *  since API 21). What we *can* do: list recently-used apps (via
     *  UsageStatsManager, needs the PACKAGE_USAGE_STATS permission granted
     *  in Settings) and let the user pick which ones to send to background /
     *  request-stop via ActivityManager.killBackgroundProcesses, which only
     *  affects cached/idle processes, not foreground ones. This opens that
     *  picker -- build it out in ui/BackgroundAppsActivity. */
    private fun closeBackgroundApps() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        // Best-effort: ask the system to trim cached processes. This is the
        // real ceiling of what's allowed without root -- it won't force-quit
        // another app's active game or service.
        am.runningAppProcesses?.forEach { proc ->
            if (proc.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED) {
                am.killBackgroundProcesses(proc.processName)
            }
        }
        closeMenu()
    }

    /** Opens a short list of quick-launch shortcuts. Hook this up to
     *  ui/QuickLaunchActivity, which should let the user pin 3-4 favorite
     *  apps from Settings, then launch them with PackageManager's
     *  getLaunchIntentForPackage(). */
    private fun quickLaunch() {
        val intent = Intent(this, com.kataloni.app.ui.MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        closeMenu()
    }

    /** Clears THIS app's own cache dir as a stand-in. Clearing other apps'
     *  caches without root requires either (a) the user doing it manually in
     *  Settings > Storage, or (b) MANAGE_EXTERNAL_STORAGE-type flows that
     *  Play Store restricts heavily -- flag this to the user honestly rather
     *  than faking a "freed 2GB" number. */
    private fun clearCache() {
        cacheDir.deleteRecursively()
        closeMenu()
    }

    /** Placeholder for a "performance mode": e.g. toggle a SharedPreference
     *  that other parts of your own app (or your games, via a shared SDK)
     *  read to reduce their own background work/animations. Without root
     *  this can't change system-wide CPU/GPU governors. */
    private fun togglePerfMode() {
        val prefs = getSharedPreferences("kataloni", Context.MODE_PRIVATE)
        val on = !prefs.getBoolean("perf_mode", false)
        prefs.edit().putBoolean("perf_mode", on).apply()
        closeMenu()
    }

    override fun onDestroy() {
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        menuView?.let { runCatching { windowManager.removeView(it) } }
        super.onDestroy()
    }
}
