package com.kataloni.app.ui

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.button.MaterialButton
import com.kataloni.app.R
import com.kataloni.app.data.ProxyRegionRepository
import com.kataloni.app.service.FloatingPanelService
import com.kataloni.app.service.ProxyVpnService
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: RegionAdapter
    private lateinit var connectButton: MaterialButton
    private lateinit var statusText: TextView
    private var connected = false

    private val vpnPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) startProxy()
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) {
            if (android.provider.Settings.canDrawOverlays(this)) startFloatingPanel()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        connectButton = findViewById(R.id.connectButton)
        val list = findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.regionList)

        adapter = RegionAdapter(ProxyRegionRepository.regions) { /* selection only, no-op here */ }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        connectButton.setOnClickListener {
            if (connected) stopProxy() else requestVpnThenConnect()
        }
    }

    private fun requestVpnThenConnect() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnPermissionLauncher.launch(intent)
        } else {
            startProxy()
        }
    }

    private fun startProxy() {
        val region = adapter.selectedRegion() ?: return
        val intent = Intent(this, ProxyVpnService::class.java).apply {
            action = ProxyVpnService.ACTION_CONNECT
            putExtra(ProxyVpnService.EXTRA_REGION_ID, region.id)
        }
        ContextCompat.startForegroundService(this, intent)

        connected = true
        statusText.text = getString(R.string.status_connected) + " · ${region.flagEmoji} ${region.countryName}"
        connectButton.text = getString(R.string.disconnect)

        ensureOverlayPermissionThenShowPanel()
    }

    private fun stopProxy() {
        val intent = Intent(this, ProxyVpnService::class.java).apply {
            action = ProxyVpnService.ACTION_DISCONNECT
        }
        startService(intent)

        connected = false
        statusText.text = getString(R.string.status_disconnected)
        connectButton.text = getString(R.string.connect)

        stopService(Intent(this, FloatingPanelService::class.java))
    }

    private fun ensureOverlayPermissionThenShowPanel() {
        if (Settings.canDrawOverlays(this)) {
            startFloatingPanel()
        } else {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun startFloatingPanel() {
        ContextCompat.startForegroundService(this, Intent(this, FloatingPanelService::class.java))
    }
}
