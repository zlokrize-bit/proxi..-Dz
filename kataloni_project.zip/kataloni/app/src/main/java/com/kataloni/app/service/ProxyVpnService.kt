package com.kataloni.app.service

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import com.kataloni.app.data.ProxyRegion

/**
 * ============================================================================
 * THIS IS THE ONE FILE YOU NEED TO FILL IN TO MAKE REGION-SWITCHING REAL.
 * ============================================================================
 *
 * Right now this class only builds a local VPN interface on the phone and
 * does NOT forward any traffic anywhere -- it is a working skeleton, not a
 * working proxy. To actually route game traffic through a server in another
 * country you need, for each region in ProxyRegion.kt, a real server that
 * speaks a tunnel protocol, e.g.:
 *
 *   - WireGuard  (recommended: fast, simple, great for games) -- use the
 *     official "com.wireguard.android:tunnel" library instead of writing
 *     your own packet forwarding here.
 *   - OpenVPN    -- use the ics-openvpn library.
 *   - A custom SOCKS5/HTTP proxy -- you'd forward packets captured on this
 *     VpnService's TUN interface to your proxy yourself (much more work).
 *
 * Practical path:
 *   1. Rent a small VPS (DigitalOcean / Vultr / AWS Lightsail, ~$5/mo each)
 *      in every country you listed in ProxyRegion.kt.
 *   2. Install WireGuard server (`wg-quick`) on each VPS -- a 10-minute setup.
 *   3. Put the matching WireGuard config (endpoint, keys) into the `host`
 *      field of each ProxyRegion, or load it from your own backend.
 *   4. Swap the body of connect()/establishTunnel() below for calls into
 *      the WireGuard-Android library, pointed at the selected region.
 *
 * Until step 2-4 are done, pressing "Connect" in this app will start a VPN
 * interface that does nothing but loop the phone's own traffic -- it will
 * NOT change which game server you connect to. Treat this file as the
 * integration point, not a finished proxy.
 */
class ProxyVpnService : VpnService() {

    private var tunInterface: ParcelFileDescriptor? = null

    companion object {
        const val EXTRA_REGION_ID = "extra_region_id"
        const val ACTION_CONNECT = "com.kataloni.app.action.CONNECT"
        const val ACTION_DISCONNECT = "com.kataloni.app.action.DISCONNECT"
        private const val TAG = "ProxyVpnService"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val regionId = intent.getStringExtra(EXTRA_REGION_ID)
                val region = com.kataloni.app.data.ProxyRegionRepository.regions
                    .firstOrNull { it.id == regionId }
                if (region != null) connect(region)
            }
            ACTION_DISCONNECT -> disconnect()
        }
        return START_STICKY
    }

    private fun connect(region: ProxyRegion) {
        Log.i(TAG, "Connecting through placeholder tunnel for ${region.countryName} (${region.host}:${region.port})")

        // Builds a local TUN interface on the device. This part is real and
        // works today. What's missing is forwarding the packets that arrive
        // on this interface to `region.host:region.port` -- see class doc.
        val builder = Builder()
            .setSession("KATA LONI - ${region.countryName}")
            .addAddress("10.8.0.2", 32)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)

        tunInterface = builder.establish()

        // TODO: hand `tunInterface` off to a real tunnel implementation
        // (e.g. WireGuard-Android's GoBackend) configured for `region`.
    }

    private fun disconnect() {
        tunInterface?.close()
        tunInterface = null
        stopSelf()
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }

    override fun onRevoke() {
        disconnect()
        super.onRevoke()
    }
}
