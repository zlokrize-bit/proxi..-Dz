package com.kataloni.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.kataloni.app.R
import com.kataloni.app.data.ProxyRegion

class RegionAdapter(
    private val regions: List<ProxyRegion>,
    private val onSelected: (ProxyRegion) -> Unit
) : RecyclerView.Adapter<RegionAdapter.VH>() {

    private var selectedId: String? = regions.firstOrNull()?.id

    inner class VH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val flag: TextView = itemView.findViewById(R.id.flag)
        val name: TextView = itemView.findViewById(R.id.countryName)
        val radio: RadioButton = itemView.findViewById(R.id.selectedRadio)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_region, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val region = regions[position]
        holder.flag.text = region.flagEmoji
        holder.name.text = region.countryName
        holder.radio.isChecked = region.id == selectedId
        holder.itemView.setOnClickListener {
            selectedId = region.id
            notifyDataSetChanged()
            onSelected(region)
        }
    }

    override fun getItemCount() = regions.size

    fun selectedRegion(): ProxyRegion? = regions.firstOrNull { it.id == selectedId }
}
